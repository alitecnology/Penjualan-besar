package com.aiasisten.control.perception

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL

/** Membaca teks halaman website (HTTPS saja; alamat lokal/privat diblokir). */
object WebTextFetcher {
    private const val MAX_BYTES = 1_500_000
    private const val MAX_TEXT = 100_000

    fun fetch(url0: String): JSONObject {
        var url = url0.trim()
        if (!url.startsWith("http", true)) url = "https://$url"
        return try {
            var current = URL(url)
            repeat(4) {
                checkSafe(current)
                val c = (current.openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false; connectTimeout = 15000; readTimeout = 20000
                    setRequestProperty("User-Agent", "AIAsistenControl/0.4.2 (Android)")
                    setRequestProperty("Accept", "text/html,text/plain,application/json,application/xml;q=0.9")
                }
                try {
                    val code = c.responseCode
                    if (code in 300..399) {
                        val loc = c.getHeaderField("Location") ?: return fail("Pengalihan tanpa tujuan.")
                        current = URL(current, loc); return@repeat
                    }
                    if (code !in 200..299) return fail("Website membalas HTTP $code.")
                    val type = (c.contentType ?: "").lowercase()
                    if (!(type.contains("html") || type.contains("text") || type.contains("json") || type.contains("xml")))
                        return fail("Tipe konten tidak didukung: $type")
                    val buf = java.io.ByteArrayOutputStream(); val tmp = ByteArray(8192); var total = 0; var trunc = false
                    c.inputStream.use { s ->
                        while (true) {
                            val n = s.read(tmp); if (n < 0) break
                            if (total + n > MAX_BYTES) { buf.write(tmp, 0, MAX_BYTES - total); trunc = true; break }
                            buf.write(tmp, 0, n); total += n
                        }
                    }
                    val raw = String(buf.toByteArray(), Charsets.UTF_8)
                    val isHtml = type.contains("html")
                    var text = if (isHtml) HtmlText.toText(raw) else raw
                    if (text.length > MAX_TEXT) { text = text.take(MAX_TEXT); trunc = true }
                    return JSONObject().put("ok", true).put("url", current.toString())
                        .put("title", if (isHtml) HtmlText.title(raw) else "").put("text", text).put("truncated", trunc)
                } finally { c.disconnect() }
            }
            fail("Terlalu banyak pengalihan.")
        } catch (e: SecurityException) { fail(e.message ?: "Diblokir.") }
        catch (e: java.net.UnknownHostException) { fail("Alamat tidak ditemukan / tidak ada internet.") }
        catch (e: java.net.SocketTimeoutException) { fail("Waktu habis.") }
        catch (e: Exception) { fail("Gagal: " + (e.message ?: e.javaClass.simpleName)) }
    }

    private fun checkSafe(u: URL) {
        if (!u.protocol.equals("https", true)) throw SecurityException("Hanya HTTPS yang diizinkan.")
        for (a in InetAddress.getAllByName(u.host)) {
            val b = a.address
            val ula = b.size == 16 && (b[0].toInt() and 0xFE) == 0xFC
            if (a.isAnyLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress || a.isSiteLocalAddress || ula)
                throw SecurityException("Alamat lokal/privat diblokir demi keamanan.")
        }
    }

    private fun fail(m: String) = JSONObject().put("ok", false).put("error", m)
}
