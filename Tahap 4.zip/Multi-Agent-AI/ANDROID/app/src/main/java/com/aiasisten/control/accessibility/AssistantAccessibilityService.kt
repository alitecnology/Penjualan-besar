package com.aiasisten.control.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tahap 4B: membaca layar (atas perintah) dan memantau perubahan tampilan (bila dinyalakan pengguna).
 * Aksi Tahap 4C dibatasi pada elemen terlihat; kolom sandi tidak dapat diisi.
 */
class AssistantAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var watching = false
    private var last: ScreenReader.Snap? = null
    private val checkTask = Runnable { checkChange() }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!watching || event == null) return
        if (event.packageName?.toString() == packageName) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            handler.removeCallbacks(checkTask); handler.postDelayed(checkTask, 800)
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        watching = false; handler.removeCallbacks(checkTask); instance = null
        return super.onUnbind(intent)
    }

    fun setWatching(on: Boolean) { watching = on; last = null; handler.removeCallbacks(checkTask) }

    /** Tahap 4C: aksi UI terbatas pada elemen yang terlihat dan tidak mengisi kolom sandi. */
    fun performUiAction(action: String, value: String = ""): JSONObject {
        val root = rootInActiveWindow ?: return JSONObject().put("ok", false).put("error", "Tidak ada layar aktif yang dapat diakses.")
        return try {
            when (action) {
                "click_text" -> {
                    val target = root.findAccessibilityNodeInfosByText(value).orEmpty()
                        .firstOrNull { it.isVisibleToUser && it.isEnabled && it.isClickable }
                        ?: return JSONObject().put("ok", false).put("error", "Tombol/teks tidak ditemukan atau tidak dapat diklik.")
                    JSONObject().put("ok", target.performAction(AccessibilityNodeInfo.ACTION_CLICK))
                }
                "type_text" -> {
                    val target = findFocusedEditable(root)
                        ?: return JSONObject().put("ok", false).put("error", "Tidak ada kolom teks aktif.")
                    if (target.isPassword) return JSONObject().put("ok", false).put("error", "Pengisian kolom sandi diblokir.")
                    val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }
                    JSONObject().put("ok", target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args))
                }
                "scroll_forward" -> JSONObject().put("ok", root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))
                "scroll_backward" -> JSONObject().put("ok", root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))
                "back" -> JSONObject().put("ok", performGlobalAction(GLOBAL_ACTION_BACK))
                else -> JSONObject().put("ok", false).put("error", "Aksi tidak diizinkan: $action")
            }
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", e.message ?: "Aksi gagal.")
        }
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isFocused && node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findFocusedEditable(child)
            if (found != null) return found
        }
        return null
    }

    private fun checkChange() {
        val snap = ScreenReader.snapshot(this) ?: return
        val prev = last; last = snap
        if (prev == null || snap.pkg == packageName) return
        val added = snap.texts - prev.texts
        val removed = prev.texts - snap.texts
        if (snap.pkg == prev.pkg && added.isEmpty() && removed.isEmpty()) return
        val json = JSONObject().put("ts", System.currentTimeMillis()).put("package", snap.pkg).put("previousPackage", prev.pkg)
            .put("addedCount", added.size).put("removedCount", removed.size)
            .put("added", JSONArray(added.take(15).map { it.take(200) }))
            .put("removed", JSONArray(removed.take(15).map { it.take(200) }))
        changeListener?.invoke(json.toString())
    }

    companion object {
        @Volatile var instance: AssistantAccessibilityService? = null
        @Volatile var changeListener: ((String) -> Unit)? = null

        /** Mendeteksi apakah pengguna masih mengaktifkan layanan (juga bila dicabut oleh Android). */
        fun isEnabled(ctx: Context): Boolean {
            val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(ctx, AssistantAccessibilityService::class.java).flattenToString()
            return enabled.split(':').any { it.equals(me, ignoreCase = true) }
        }
    }
}
