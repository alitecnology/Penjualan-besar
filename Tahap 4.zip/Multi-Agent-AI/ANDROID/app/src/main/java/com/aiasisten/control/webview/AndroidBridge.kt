package com.aiasisten.control.webview

import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.aiasisten.control.MainActivity
import com.aiasisten.control.accessibility.AssistantAccessibilityService
import com.aiasisten.control.accessibility.ScreenReader
import com.aiasisten.control.perception.AssistantNotificationListener
import com.aiasisten.control.perception.FileExtractor
import com.aiasisten.control.perception.NotificationAllowlist
import com.aiasisten.control.perception.WebTextFetcher
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Jembatan JavaScript yang aman: hanya fungsi bertanda @JavascriptInterface, dan API Key tidak pernah dikembalikan. */
class AndroidBridge(private val activity: MainActivity, private val webView: WebView) {
    private val store = SecureStore(activity)
    private val pool = Executors.newCachedThreadPool()
    private val generation = AtomicInteger(0)
    private val ui = Handler(Looper.getMainLooper())
    val voice = VoiceController(activity, ::emit)

    init {
        AssistantAccessibilityService.changeListener = { json -> emit("screen_change", "", json) }
        AssistantNotificationListener.onPosted = { json -> emit("notification", "", json) }
    }

    fun emit(type: String, id: String, data: String) {
        val js = "window.NativeEvents&&window.NativeEvents.dispatch(${JSONObject.quote(type)},${JSONObject.quote(id)},${JSONObject.quote(data)})"
        webView.post { webView.evaluateJavascript(js, null) }
    }

    fun close() {
        generation.incrementAndGet()
        voice.release()
        AssistantAccessibilityService.instance?.setWatching(false)
        AssistantAccessibilityService.changeListener = null
        AssistantNotificationListener.onPosted = null
    }

    private fun err(m: String) = JSONObject().put("ok", false).put("error", m).toString()

    // ---------- Tahap 4A ----------
    @JavascriptInterface fun getModel(): String = GeminiClient.MODEL
    @JavascriptInterface fun hasApiKey(): Boolean = store.hasApiKey()
    @JavascriptInterface fun saveApiKey(key: String): Boolean = store.saveApiKey(key.trim())
    @JavascriptInterface fun clearApiKey() = store.clearApiKey()

    @JavascriptInterface fun askGemini(requestId: String, payload: String) {
        val gen = generation.get()
        val key = store.getApiKey()
        if (key == null) { emit("gemini", requestId, err("API Key belum diisi.")); return }
        pool.execute {
            val result = GeminiClient.generate(key, payload) { generation.get() != gen }
            if (generation.get() == gen) emit("gemini", requestId, result.toString())
        }
    }

    @JavascriptInterface fun startVoice() { activity.runOnUiThread { voice.start() } }
    @JavascriptInterface fun stopVoice() { activity.runOnUiThread { voice.stop() } }
    @JavascriptInterface fun requestMicPermission() { activity.runOnUiThread { activity.ensureMicPermission { } } }

    @JavascriptInterface fun permissionStatus(): String = JSONObject()
        .put("mic", activity.hasMicPermission())
        .put("accessibility", AssistantAccessibilityService.isEnabled(activity))
        .put("notifications", AssistantNotificationListener.isEnabled(activity))
        .toString()

    @JavascriptInterface fun openAccessibilitySettings() {
        activity.runOnUiThread { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    // ---------- Tahap 4B: melihat & membaca ----------
    /** Membaca layar aktif setelah jeda (agar pengguna sempat membuka aplikasi lain). Hasil: event id=requestId. */
    @JavascriptInterface fun readScreen(requestId: String, delaySeconds: Int) {
        val gen = generation.get()
        ui.postDelayed({
            if (generation.get() != gen) { emit("screen", requestId, err("Dibatalkan (Emergency Stop).")); return@postDelayed }
            val svc = AssistantAccessibilityService.instance
            if (svc == null) emit("screen", requestId, err("Accessibility Service belum aktif. Aktifkan di menu Keamanan."))
            else emit("screen", requestId, ScreenReader.read(svc).toString())
        }, delaySeconds.coerceIn(0, 15) * 1000L)
    }

    @JavascriptInterface fun watchScreen(on: Boolean): Boolean {
        val svc = AssistantAccessibilityService.instance ?: return false
        svc.setWatching(on); return true
    }

    @JavascriptInterface fun notificationStatus(): String = JSONObject()
        .put("enabled", AssistantNotificationListener.isEnabled(activity))
        .put("allowed", JSONArray(NotificationAllowlist.get(activity).toList()))
        .toString()

    @JavascriptInterface fun openNotificationAccessSettings() {
        activity.runOnUiThread { activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    @JavascriptInterface fun setAllowedPackages(json: String): Boolean = try {
        val a = JSONArray(json); val set = HashSet<String>()
        for (i in 0 until a.length()) a.getString(i).trim().takeIf { it.matches(Regex("[A-Za-z0-9_.]{3,100}")) }?.let { set.add(it) }
        NotificationAllowlist.set(activity, set); true
    } catch (e: Exception) { false }

    @JavascriptInterface fun recentNotifications(): String = AssistantNotificationListener.recent().toString()
    @JavascriptInterface fun clearNotifications() = AssistantNotificationListener.clear()

    /** Pengguna memilih berkas lewat pemilih Android; isinya dibaca di latar belakang. */
    @JavascriptInterface fun pickFiles(requestId: String) {
        activity.runOnUiThread {
            activity.pickDocuments { uris ->
                if (uris.isEmpty()) { emit("files", requestId, JSONObject().put("ok", true).put("files", JSONArray()).toString()); return@pickDocuments }
                pool.execute {
                    val arr = JSONArray()
                    uris.take(10).forEach { arr.put(FileExtractor.extract(activity, it)) }
                    emit("files", requestId, JSONObject().put("ok", true).put("files", arr).toString())
                }
            }
        }
    }

    // ---------- Tahap 4C: eksekusi aksi perangkat dengan izin pengguna ----------
    @JavascriptInterface fun executeAction(requestId: String, action: String, value: String) {
        val gen = generation.get()
        val allowed = setOf("click_text", "type_text", "scroll_forward", "scroll_backward", "back", "open_url", "open_app")
        if (action !in allowed) { emit("action", requestId, err("Jenis aksi tidak diizinkan.")); return }
        when (action) {
            "open_url" -> {
                val uri = try { Uri.parse(value) } catch (_: Exception) { null }
                if (uri == null || uri.scheme !in setOf("https", "http") || uri.host.isNullOrBlank()) {
                    emit("action", requestId, err("Alamat URL tidak valid.")); return
                }
                activity.runOnUiThread {
                    if (generation.get() != gen) { emit("action", requestId, err("Dibatalkan (Emergency Stop).")); return@runOnUiThread }
                    try {
                        activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
                        emit("action", requestId, JSONObject().put("ok", true).put("message", "Permintaan membuka URL dikirim ke Android." ).toString())
                    } catch (e: Exception) { emit("action", requestId, err(e.message ?: "Tidak dapat membuka URL.")) }
                }
            }
            "open_app" -> {
                if (!value.matches(Regex("[A-Za-z0-9_.]{3,150}"))) { emit("action", requestId, err("ID paket aplikasi tidak valid.")); return }
                activity.runOnUiThread {
                    if (generation.get() != gen) { emit("action", requestId, err("Dibatalkan (Emergency Stop).")); return@runOnUiThread }
                    try {
                        val launch = activity.packageManager.getLaunchIntentForPackage(value)
                        if (launch == null) emit("action", requestId, err("Aplikasi tidak ditemukan atau tidak memiliki launcher."))
                        else { activity.startActivity(launch); emit("action", requestId, JSONObject().put("ok", true).put("message", "Aplikasi dibuka." ).toString()) }
                    } catch (e: Exception) { emit("action", requestId, err(e.message ?: "Gagal membuka aplikasi.")) }
                }
            }
            else -> {
                val svc = AssistantAccessibilityService.instance
                if (svc == null) emit("action", requestId, err("Aktifkan Accessibility Service terlebih dahulu."))
                else pool.execute {
                    if (generation.get() != gen) emit("action", requestId, err("Dibatalkan (Emergency Stop)."))
                    else emit("action", requestId, svc.performUiAction(action, value).toString())
                }
            }
        }
    }

    @JavascriptInterface fun fetchWebText(requestId: String, url: String) {
        val gen = generation.get()
        pool.execute {
            val r = WebTextFetcher.fetch(url)
            if (generation.get() == gen) emit("web", requestId, r.toString())
        }
    }

    /** Emergency Stop: batalkan permintaan AI, hentikan suara & pemantauan layar, hapus buffer notifikasi. */
    @JavascriptInterface fun emergencyStop() {
        generation.incrementAndGet()
        AssistantAccessibilityService.instance?.setWatching(false)
        AssistantNotificationListener.clear()
        activity.runOnUiThread { voice.stop(silent = true) }
    }
}
