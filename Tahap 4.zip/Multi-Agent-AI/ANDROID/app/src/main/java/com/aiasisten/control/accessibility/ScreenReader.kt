package com.aiasisten.control.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/** Tahap 4B: membaca isi layar aktif sebagai teks. Kolom sandi TIDAK dibaca. */
object ScreenReader {
    private const val MAX_NODES = 500
    private const val MAX_CHARS = 30_000

    class Snap(val pkg: String, val lines: List<String>, val texts: Set<String>, val truncated: Boolean)

    private class Acc { val lines = ArrayList<String>(); val texts = LinkedHashSet<String>(); var nodes = 0; var chars = 0; var truncated = false }

    fun snapshot(svc: AccessibilityService): Snap? {
        val root = svc.rootInActiveWindow ?: return null
        val acc = Acc()
        try { walk(root, 0, acc) } finally { @Suppress("DEPRECATION") root.recycle() }
        return Snap(root.packageName?.toString() ?: "?", acc.lines, acc.texts, acc.truncated)
    }

    fun read(svc: AccessibilityService): JSONObject {
        val s = snapshot(svc) ?: return JSONObject().put("ok", false)
            .put("error", "Layar tidak dapat dibaca (tidak ada jendela aktif, atau aplikasi memblokir pembacaan).")
        return JSONObject().put("ok", true).put("package", s.pkg).put("lines", s.lines.size)
            .put("truncated", s.truncated).put("text", s.lines.joinToString("\n"))
    }

    private fun walk(n: AccessibilityNodeInfo, depth: Int, acc: Acc) {
        if (acc.nodes >= MAX_NODES || acc.chars >= MAX_CHARS) { acc.truncated = true; return }
        acc.nodes++
        if (n.isVisibleToUser) {
            val pwd = n.isPassword
            val raw = if (pwd) "(kolom sandi disembunyikan)" else n.text?.toString()?.take(300)
            val desc = if (pwd) null else n.contentDescription?.toString()?.take(200)
            val hint = if (pwd) null else n.hintText?.toString()?.take(100)
            val parts = ArrayList<String>()
            if (!raw.isNullOrBlank()) parts.add(raw)
            if (!desc.isNullOrBlank() && desc != raw) parts.add("[ket: $desc]")
            if (!hint.isNullOrBlank() && hint != raw) parts.add("[petunjuk: $hint]")
            if (parts.isNotEmpty()) {
                val flags = StringBuilder()
                if (n.isClickable) flags.append("[klik]")
                if (n.isEditable) flags.append("[isian]")
                if (n.isCheckable) flags.append(if (n.isChecked) "[✔]" else "[☐]")
                val line = "  ".repeat(minOf(depth, 8)) + parts.joinToString(" ") + (if (flags.isNotEmpty()) " $flags" else "")
                acc.lines.add(line); acc.chars += line.length
                if (!pwd && !raw.isNullOrBlank()) acc.texts.add(raw.trim())
            }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, depth + 1, acc)
            @Suppress("DEPRECATION") c.recycle()
        }
    }
}
