'use strict';
/* AI Asisten Control — perception.js
   Tahap 4B: AI 1 (Pekerja) melihat & membaca: layar, notifikasi (diizinkan), teks website, file, perubahan tampilan.
   Semua hasil adalah DATA; dikirim ke AI hanya jika pengguna menekan "Kirim ke perintah". */
(function () {
  const { Native } = window.Agents;
  const $ = id => document.getElementById(id);
  const MAX_ITEMS = 20;
  const items = [];
  const PKG_PRESETS = [['WhatsApp', 'com.whatsapp'], ['Telegram', 'org.telegram.messenger'], ['Gmail', 'com.google.android.gm'], ['Pesan', 'com.google.android.apps.messaging']];

  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const log = (t) => window.Chat && window.Chat.activity(t, 'Indra');
  const need = () => { if (Native.available()) return true; ['screenState', 'notifState', 'webState', 'fileState'].forEach(i => { $(i).textContent = 'Fitur ini hanya tersedia di aplikasi Android.'; }); return false; };

  /* ---------- Daftar hasil ---------- */
  function addItem(it) {
    it.ts = Date.now(); items.unshift(it); if (items.length > MAX_ITEMS) items.pop(); render();
  }
  function render() {
    const ul = $('indraItems'); ul.replaceChildren();
    if (!items.length) { ul.appendChild(el('li', 'muted', 'Belum ada.')); return; }
    items.forEach(it => {
      const li = el('li'), d = el('details');
      const sum = el('summary'); sum.appendChild(el('b', null, `${it.icon} ${it.name}`)); sum.appendChild(el('span', 'muted', `  ${it.meta || ''}`));
      d.appendChild(sum);
      d.appendChild(el('pre', 'code', (it.text || '(kosong)').slice(0, 6000) + ((it.text || '').length > 6000 ? '\n… (tampilan dipotong; seluruh isi tetap dikirim)' : '')));
      const act = el('div', 'item-actions');
      const send = el('button', 'btn small', 'Kirim ke perintah');
      send.onclick = () => { window.Chat.addAttachment({ name: it.name, size: (it.text || '').length, type: it.type, text: it.text }); window.App.go('perintah'); };
      act.appendChild(send); d.appendChild(act); li.appendChild(d); ul.appendChild(li);
    });
  }

  /* ---------- Layar ---------- */
  async function readScreen() {
    if (!need()) return;
    const st = $('screenState'), btn = $('btnReadScreen'); btn.disabled = true;
    st.textContent = 'Buka aplikasi yang ingin dibaca… membaca dalam 5 detik.';
    const r = await Native.request('readScreen', 5);
    btn.disabled = false;
    if (!r.ok) { st.textContent = '⚠️ ' + r.error; return; }
    st.textContent = `✔ ${r.lines} baris dibaca dari ${r.package}${r.truncated ? ' (dipotong)' : ''}.`;
    addItem({ icon: '👁️', name: 'Layar ' + r.package, type: 'layar', meta: r.lines + ' baris', text: r.text }); log('Membaca layar ' + r.package);
  }
  function toggleWatch(on) {
    if (!need()) { $('optWatch').checked = false; return; }
    const ok = Native.call('watchScreen', on) === true;
    if (!ok) { $('optWatch').checked = false; $('screenState').textContent = '⚠️ Accessibility Service belum aktif (menu Keamanan).'; return; }
    $('screenState').textContent = on ? '👀 Memantau perubahan tampilan aplikasi lain.' : 'Pemantauan dimatikan.'; log(on ? 'Pemantauan layar dinyalakan.' : 'Pemantauan layar dimatikan.');
  }
  Native.on('screen_change', ev => {
    const parts = [`Aplikasi: ${ev.package}${ev.previousPackage !== ev.package ? ' (sebelumnya ' + ev.previousPackage + ')' : ''}`];
    if (ev.added.length) parts.push('Muncul:\n- ' + ev.added.join('\n- '));
    if (ev.removed.length) parts.push('Hilang:\n- ' + ev.removed.join('\n- '));
    addItem({ icon: '🔄', name: 'Perubahan ' + ev.package, type: 'perubahan_tampilan', meta: `+${ev.addedCount} / −${ev.removedCount}`, text: parts.join('\n\n') });
  });

  /* ---------- Notifikasi ---------- */
  function renderChips() {
    const box = $('pkgChips'); box.replaceChildren();
    PKG_PRESETS.forEach(([n, p]) => { const c = el('button', 'chip', '+ ' + n); c.onclick = () => { const v = $('allowPkgs').value.split(',').map(s => s.trim()).filter(Boolean); if (!v.includes(p)) v.push(p); $('allowPkgs').value = v.join(', '); }; box.appendChild(c); });
  }
  function saveAllowed() {
    if (!need()) return;
    const list = $('allowPkgs').value.split(',').map(s => s.trim()).filter(Boolean);
    const ok = Native.call('setAllowedPackages', JSON.stringify(list)) === true;
    $('notifState').textContent = ok ? `✔ ${list.length} aplikasi diizinkan.` : '⚠️ Gagal menyimpan.'; log('Daftar izin notifikasi diperbarui.');
  }
  function showNotifs() {
    if (!need()) return;
    const st = Native.json('notificationStatus');
    if (st && !st.enabled) { $('notifState').textContent = '⚠️ Akses notifikasi belum aktif. Buka menu Keamanan → "Buka akses notifikasi".'; return; }
    const list = Native.json('recentNotifications') || [];
    if (!list.length) { $('notifState').textContent = 'Belum ada notifikasi dari aplikasi yang diizinkan.'; return; }
    const text = list.map(n => `[${new Date(n.ts).toLocaleString('id-ID')}] ${n.package}\n${n.title}\n${n.text}`).join('\n\n');
    addItem({ icon: '🔔', name: 'Notifikasi', type: 'notifikasi', meta: list.length + ' item', text }); $('notifState').textContent = `✔ ${list.length} notifikasi dibaca.`; log('Membaca notifikasi.');
  }
  Native.on('notification', n => { $('notifState').textContent = `🔔 Baru: ${n.package} — ${n.title}`; });

  /* ---------- Website ---------- */
  async function readWeb() {
    if (!need()) return;
    const url = $('webUrl').value.trim(); if (!url) { $('webState').textContent = 'Isi alamat website dulu.'; return; }
    $('webState').textContent = 'Membaca…'; $('btnReadWeb').disabled = true;
    const r = await Native.request('fetchWebText', url);
    $('btnReadWeb').disabled = false;
    if (!r.ok) { $('webState').textContent = '⚠️ ' + r.error; return; }
    $('webState').textContent = `✔ ${r.text.length} karakter dibaca${r.truncated ? ' (dipotong)' : ''}.`;
    addItem({ icon: '🌐', name: r.title || r.url, type: 'website', meta: r.url, text: r.text }); log('Membaca website ' + r.url);
  }

  /* ---------- File ---------- */
  async function pickFiles(attach) {
    if (!need()) return;
    $('fileState').textContent = 'Memilih & membaca file…';
    const r = await Native.request('pickFiles');
    if (!r.ok || !r.files.length) { $('fileState').textContent = r.ok ? 'Tidak ada file dipilih.' : '⚠️ ' + r.error; return; }
    let okCount = 0;
    r.files.forEach(f => {
      if (f.error) { $('fileState').textContent = `⚠️ ${f.name}: ${f.error}`; return; }
      okCount++;
      const meta = `${f.kind} · ${f.chars} karakter${f.truncated ? ' (dipotong)' : ''}${f.note ? ' · ' + f.note : ''}`;
      addItem({ icon: '📄', name: f.name, type: f.kind, meta, text: f.text });
      if (attach) window.Chat.addAttachment({ name: f.name, size: f.size, type: f.type, text: f.text });
    });
    if (okCount) $('fileState').textContent = `✔ ${okCount} file dibaca.`; log(`Membaca ${okCount} file.`);
  }

  function refresh() { const st = Native.json('notificationStatus'); if (st) $('allowPkgs').value = st.allowed.join(', '); }
  function stopAll() { $('optWatch').checked = false; $('btnReadScreen').disabled = false; $('btnReadWeb').disabled = false; items.length = 0; render(); }

  function init() {
    renderChips();
    $('btnReadScreen').onclick = readScreen;
    $('optWatch').onchange = e => toggleWatch(e.target.checked);
    $('btnSaveAllowed').onclick = saveAllowed;
    $('btnRefreshNotif').onclick = showNotifs;
    $('btnClearNotif').onclick = () => { Native.call('clearNotifications'); $('notifState').textContent = 'Buffer notifikasi dihapus.'; };
    $('btnReadWeb').onclick = readWeb;
    $('webUrl').addEventListener('keydown', e => { if (e.key === 'Enter') readWeb(); });
    $('btnPickFiles').onclick = () => pickFiles(false);
    $('btnClearItems').onclick = () => { items.length = 0; render(); };
    render();
  }

  window.Perception = { init, refresh, pickFiles, stopAll };
})();
