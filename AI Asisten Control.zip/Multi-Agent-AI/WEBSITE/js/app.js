'use strict';
/* AI Asisten Control — app.js : navigasi, pengaturan, izin, emergency stop */
(function () {
  const { Native, Worker, MODEL } = window.Agents;
  const $ = id => document.getElementById(id);

  function go(view) {
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + view));
    document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    if (view === 'riwayat') window.Chat.renderHistory();
    if (view === 'keamanan') refreshPerms();
    if (view === 'pengaturan') refreshKey();
    if (view === 'indra') window.Perception.refresh();
  }

  function refreshKey() {
    const has = Native.available() && Native.call('hasApiKey') === true;
    $('statApi').textContent = !Native.available() ? 'Browser' : has ? 'Tersimpan' : 'Kosong';
    $('keyState').textContent = !Native.available() ? 'Mode browser: API Key hanya bisa disimpan di aplikasi Android.' : has ? '✔ API Key tersimpan (terenkripsi).' : 'API Key belum disimpan.';
    const b = $('connBadge');
    b.textContent = !Native.available() ? 'Mode uji (browser)' : has ? 'Siap · ' + MODEL : 'API Key kosong';
    b.className = 'badge ' + (has ? 'ok' : 'bad');
  }

  function refreshPerms() {
    const p = Native.json('permissionStatus');
    $('permNet').textContent = p ? 'Terhubung' : 'Tidak ada (mode browser)';
    $('permMic').textContent = p ? (p.mic ? 'Diizinkan ✔' : 'Belum diizinkan') : '–';
    $('permAcc').textContent = p ? (p.accessibility ? 'Aktif ✔' : 'Nonaktif') : '–';
    $('permNotif').textContent = p ? (p.notifications ? 'Aktif ✔' : 'Nonaktif') : '–';
  }

  function init() {
    $('modelName').textContent = MODEL;
    document.querySelectorAll('#nav button').forEach(b => { b.onclick = () => go(b.dataset.view); });

    $('btnSaveKey').onclick = () => {
      const k = $('apiKeyInput').value.trim();
      if (k.length < 20) { $('keyState').textContent = '⚠️ API Key tampak terlalu pendek.'; return; }
      const ok = Native.call('saveApiKey', k) === true;
      $('apiKeyInput').value = '';
      refreshKey(); if (!ok) $('keyState').textContent = '⚠️ Gagal menyimpan (hanya di aplikasi Android).';
    };
    $('btnClearKey').onclick = () => { Native.call('clearApiKey'); refreshKey(); };
    $('btnTestKey').onclick = async () => {
      $('keyState').textContent = 'Menguji koneksi…';
      const r = await Worker.testConnection();
      $('keyState').textContent = r.ok ? '✔ Terhubung: ' + String(r.text).slice(0, 60) : '⚠️ ' + r.error;
    };

    $('btnReqMic').onclick = () => { Native.call('requestMicPermission'); setTimeout(refreshPerms, 1500); };
    $('btnOpenNotif').onclick = () => Native.call('openNotificationAccessSettings');
    $('btnOpenAcc').onclick = () => Native.call('openAccessibilitySettings');
    $('btnRefreshPerm').onclick = refreshPerms;
    document.addEventListener('visibilitychange', () => { if (!document.hidden) { refreshKey(); refreshPerms(); } });

    $('tabConv').onclick = () => { $('histConv').hidden = false; $('histTask').hidden = true; $('tabConv').classList.add('active'); $('tabTask').classList.remove('active'); };
    $('tabTask').onclick = () => { $('histConv').hidden = true; $('histTask').hidden = false; $('tabTask').classList.add('active'); $('tabConv').classList.remove('active'); };
    $('btnClearHist').onclick = () => { if (confirm('Hapus semua riwayat?')) window.Chat.clearHistory(); };

    $('btnStop').onclick = () => {
      Native.call('emergencyStop'); Native.cancelAll(); window.Chat.reset(); if (window.Perception) window.Perception.stopAll();
      window.Chat.setStatus('Dihentikan', 'warn'); window.Chat.activity('EMERGENCY STOP: semua proses dihentikan.', 'Sistem');
    };

    window.Chat.init(); window.Perception.init(); refreshKey();
  }

  window.App = { go };
  document.addEventListener('DOMContentLoaded', init);
})();
