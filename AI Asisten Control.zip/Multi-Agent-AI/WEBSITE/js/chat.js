'use strict';
/* AI Asisten Control — chat.js : antarmuka percakapan, suara, lampiran, riwayat */
(function () {
  const { Native, Worker, Context } = window.Agents;
  const $ = id => document.getElementById(id);
  const LS = { conv: 'mac.history.conv', task: 'mac.history.task', stats: 'mac.stats', auto: 'mac.autosend' };
  const state = { busy: false, round: 0, attachments: [], recording: false, stats: { cmd: 0, clar: 0 } };

  const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } };
  const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* abaikan */ } };
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const hhmm = ts => new Date(ts).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
  const cap = (a, n) => { if (a.length > n) a.splice(0, a.length - n); return a; };

  /* ---------- Log aktivitas & diskusi ---------- */
  function logTo(listId, text, who) {
    const ul = $(listId); if (!ul) return;
    const first = ul.firstElementChild; if (first && first.classList.contains('muted')) first.remove();
    const li = el('li'); li.appendChild(el('time', null, hhmm(Date.now())));
    if (who) li.appendChild(el('b', null, who + ': '));
    li.appendChild(document.createTextNode(text));
    ul.prepend(li); while (ul.children.length > 50) ul.lastChild.remove();
  }
  const activity = (t, who) => logTo('dashActivity', t, who);
  const discuss = (who, t) => logTo('discussLog', t, who);
  function setStatus(text, cls) { const p = $('stWorker'); p.textContent = text; p.className = 'pill ' + (cls || ''); }

  /* ---------- Render pesan ---------- */
  function addMsg(kind, text) {
    const log = $('chatLog'), m = el('div', 'msg ' + kind, text);
    log.appendChild(m); log.scrollTop = log.scrollHeight; return m;
  }
  function renderUnderstanding(r) {
    const d = r.data, m = el('div', 'msg ai');
    m.appendChild(el('h4', null, 'AI Pekerja' + (r.source === 'lokal' ? ' · mode lokal' : '')));
    m.appendChild(el('div', null, d.balasan_ke_pengguna));
    const kv = el('div', 'kv');
    const row = (k, v) => { if (!v) return; kv.appendChild(el('b', null, k)); kv.appendChild(el('span', null, v)); };
    row('Niat', d.niat.replace(/_/g, ' '));
    row('Tujuan', d.tujuan_utama);
    row('Keyakinan', d.keyakinan + '%');
    row('Risiko', d.tingkat_risiko + (d.perlu_konfirmasi_pengguna ? ' · perlu konfirmasi' : ''));
    row('Rujukan', d.rujukan_konteks);
    m.appendChild(kv);
    if (d.poin_permintaan.length > 1 || r.pre.long) {
      const ol = el('ol'); d.poin_permintaan.forEach(p => ol.appendChild(el('li', null, `${p.isi} [${p.prioritas}]`))); m.appendChild(ol);
    }
    const tags = el('div', 'tags');
    Object.entries(d.entitas).forEach(([k, v]) => v.forEach(x => tags.appendChild(el('span', 'chip static', k + ': ' + (typeof x === 'string' ? x : JSON.stringify(x))))));
    if (tags.children.length) m.appendChild(tags);
    if (d.asumsi.length) m.appendChild(el('div', 'muted', 'Asumsi: ' + d.asumsi.join('; ')));
    const log = $('chatLog'); log.appendChild(m); log.scrollTop = log.scrollHeight;
  }

  /* ---------- Klarifikasi ---------- */
  function showClarify(qs) {
    const box = $('clarifyChips'); box.replaceChildren();
    qs.forEach(q => {
      q.pilihan.forEach(p => { const c = el('button', 'chip', p); c.onclick = () => send(p); box.appendChild(c); });
    });
  }
  const clearClarify = () => $('clarifyChips').replaceChildren();

  /* ---------- Kirim perintah ---------- */
  async function send(textArg) {
    if (state.busy) return;
    const input = $('cmdInput'), text = (textArg != null ? textArg : input.value).trim();
    if (!text) return;
    input.value = ''; clearClarify();
    state.busy = true; $('btnSend').disabled = true;
    const attachments = state.attachments.slice(); state.attachments = []; renderAttach();
    addMsg('user', text + (attachments.length ? '\n📎 ' + attachments.map(a => a.name).join(', ') : ''));
    const conv = load(LS.conv, []); conv.push({ ts: Date.now(), role: 'Anda', text }); save(LS.conv, cap(conv, 200));
    const wait = addMsg('ai', 'Memahami perintah…'); wait.classList.add('typing');
    setStatus('Memahami…', 'warn'); activity('Mulai memahami perintah.', 'Pekerja');

    const forceAssume = state.round >= Worker.MAX_CLARIFY_ROUNDS;
    const r = await Worker.understand(text, { attachments, forceAssume });
    wait.remove();

    if (!r.ok) {
      addMsg('err', r.error); setStatus('Gagal', ''); activity('Gagal: ' + r.error, 'Pekerja');
      if (r.needKey) window.App && window.App.go('pengaturan');
    } else {
      renderUnderstanding(r);
      $('workerLast').textContent = JSON.stringify(r.data, null, 2);
      const d = r.data;
      if (d.perlu_klarifikasi && d.pertanyaan_klarifikasi.length) {
        state.round++; state.stats.clar++;
        d.pertanyaan_klarifikasi.forEach(q => addMsg('ai', '❓ ' + q.pertanyaan));
        showClarify(d.pertanyaan_klarifikasi);
        $('counter').textContent = `Klarifikasi ${state.round}/${Worker.MAX_CLARIFY_ROUNDS}`;
        discuss('Pekerja', 'Meminta klarifikasi: ' + d.pertanyaan_klarifikasi.map(q => q.pertanyaan).join(' | '));
        activity('Meminta klarifikasi.', 'Pekerja'); setStatus('Menunggu jawaban', 'warn');
      } else {
        state.round = 0; state.stats.cmd++; $('counter').textContent = '';
        const tasks = load(LS.task, []);
        tasks.push({ ts: Date.now(), text: d.ringkasan || text, niat: d.niat, risiko: d.tingkat_risiko, status: 'Dipahami (belum dieksekusi — Tahap 4C)' });
        save(LS.task, cap(tasks, 200));
        discuss('Pekerja', `Memahami: ${d.ringkasan} (keyakinan ${d.keyakinan}%, risiko ${d.tingkat_risiko}).`);
        discuss('Pengoreksi', 'Belum aktif (Tahap 5).');
        activity('Perintah dipahami: ' + d.niat.replace(/_/g, ' '), 'Pekerja'); setStatus('Siap', 'ok');
      }
      save(LS.stats, state.stats); refreshStats();
      const c2 = load(LS.conv, []); c2.push({ ts: Date.now(), role: 'Pekerja', text: d.balasan_ke_pengguna }); save(LS.conv, cap(c2, 200));
    }
    state.busy = false; $('btnSend').disabled = false; input.focus();
  }

  /* ---------- Lampiran ---------- */
  function renderAttach() {
    const box = $('attachList'); box.replaceChildren();
    state.attachments.forEach((f, i) => { const c = el('button', 'chip', '📎 ' + f.name + (f.text ? ' ✔' : '') + ' ✕'); c.onclick = () => { state.attachments.splice(i, 1); renderAttach(); }; box.appendChild(c); });
  }

  /* ---------- Suara ---------- */
  function setRecording(on) { state.recording = on; const b = $('btnMic'); b.classList.toggle('rec', on); b.textContent = on ? '⏹' : '🎤'; }
  function initVoice() {
    $('btnMic').onclick = () => {
      if (!Native.available()) { $('voiceState').textContent = 'Suara hanya tersedia di aplikasi Android.'; return; }
      if (state.recording) { Native.call('stopVoice'); } else { Native.call('startVoice'); }
    };
    Native.on('voice', ev => {
      const vs = $('voiceState');
      switch (ev.state) {
        case 'listening': setRecording(true); vs.textContent = '🎙️ Mendengarkan…'; break;
        case 'partial': $('cmdInput').value = ev.text; break;
        case 'final':
          setRecording(false); vs.textContent = ''; $('cmdInput').value = ev.text;
          if ($('optAutoSend') && $('optAutoSend').checked) send();
          break;
        case 'error': setRecording(false); vs.textContent = '⚠️ ' + (ev.message || 'Suara gagal.'); break;
        case 'stopped': setRecording(false); vs.textContent = ''; break;
      }
    });
  }

  /* ---------- Riwayat ---------- */
  function renderHistory() {
    const fill = (id, items, fmt) => {
      const ul = $(id); ul.replaceChildren();
      if (!items.length) { ul.appendChild(el('li', 'muted', 'Belum ada data.')); return; }
      items.slice().reverse().forEach(it => { const li = el('li'); li.appendChild(el('time', null, new Date(it.ts).toLocaleString('id-ID'))); li.appendChild(document.createTextNode(fmt(it))); ul.appendChild(li); });
    };
    fill('histConv', load(LS.conv, []), i => `${i.role}: ${i.text}`);
    fill('histTask', load(LS.task, []), i => `${i.text} — ${i.status} [${i.niat}, risiko ${i.risiko}]`);
  }
  function clearHistory() { save(LS.conv, []); save(LS.task, []); renderHistory(); }

  function refreshStats() { $('statCmd').textContent = state.stats.cmd; $('statClar').textContent = state.stats.clar; }

  function init() {
    state.stats = load(LS.stats, { cmd: 0, clar: 0 }); refreshStats();
    $('btnSend').onclick = () => send();
    $('cmdInput').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
    $('btnAttach').onclick = () => { if (Native.available() && window.Perception) window.Perception.pickFiles(true); else $('fileInput').click(); };
    $('fileInput').onchange = async e => {
      for (const f of Array.from(e.target.files)) {
        const a = { name: f.name, size: f.size, type: f.type };
        if (/^text\/|\.(txt|md|csv|json|html?|js|css|xml)$/i.test(f.type + f.name) && f.size <= 200000) { try { a.text = await f.text(); } catch (_) { /* abaikan */ } }
        state.attachments.push(a);
      }
      e.target.value = ''; renderAttach();
    };
    $('optAutoSend').checked = load(LS.auto, false);
    $('optAutoSend').onchange = e => save(LS.auto, e.target.checked);
    initVoice();
  }

  function addAttachment(a) { state.attachments.push(a); renderAttach(); }

  window.Chat = { init, addAttachment, send, renderHistory, clearHistory, activity, discuss, setStatus, reset() { Context.reset(); state.round = 0; clearClarify(); state.busy = false; $('btnSend').disabled = false; } };
})();
