# WEBSITE — AI Asisten Control
Dashboard Dark Professional (HTML/CSS/JS murni). File dimuat langsung oleh aplikasi Android dari folder ini (lihat `ANDROID/app/build.gradle`, `assets.srcDirs`).
- `js/agents.js` — jembatan Android + AI Pekerja (pemahaman perintah)
- `js/chat.js` — percakapan, suara, lampiran, riwayat
- `js/app.js` — navigasi, pengaturan API Key, izin, Emergency Stop
Uji cepat tanpa Android: buka `index.html` di browser (mode lokal sederhana, tanpa AI).
