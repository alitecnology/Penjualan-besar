Letakkan gambar di sini.
