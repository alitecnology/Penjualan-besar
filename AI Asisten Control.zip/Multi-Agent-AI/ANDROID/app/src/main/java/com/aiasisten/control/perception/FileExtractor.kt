package com.aiasisten.control.perception

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Membaca isi file: TXT/kode/HTML, PDF, ZIP, DOCX/XLSX/PPTX/ODF. Hanya membaca, tidak mengubah file. */
object FileExtractor {
    private const val MAX_TEXT = 200_000
    private const val MAX_BYTES = 25L * 1024 * 1024
    private val TEXT_EXT = setOf("txt", "md", "csv", "tsv", "json", "xml", "html", "htm", "js", "mjs", "ts", "css", "kt", "java", "py", "sh",
        "yml", "yaml", "ini", "log", "gradle", "properties", "sql", "svg", "c", "cpp", "h", "cs", "php", "rb", "go", "rs", "swift", "toml")
    private val OFFICE_EXT = setOf("docx", "xlsx", "pptx", "odt", "ods", "odp")

    private class R(val text: String, val truncated: Boolean, val note: String, val kind: String)

    fun extract(ctx: Context, uri: Uri): JSONObject {
        var name = "berkas"; var size = -1L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = ctx.contentResolver.getType(uri) ?: ""
        val out = JSONObject().put("name", name).put("size", size).put("type", mime.ifEmpty { ext })
        if (size > MAX_BYTES) return out.put("error", "Berkas terlalu besar (maks 25 MB).")
        return try {
            fun open(): InputStream = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Tidak bisa membuka berkas.")
            val r = when {
                ext == "pdf" || mime == "application/pdf" -> pdf(ctx, open())
                ext == "zip" || mime == "application/zip" -> zip(open())
                ext in OFFICE_EXT -> office(open(), ext)
                ext in TEXT_EXT || mime.startsWith("text/") || mime == "application/json" -> text(open(), ext)
                else -> R("", false, "Format belum didukung — hanya nama/ukuran yang dibaca.", "tidak_didukung")
            }
            out.put("kind", r.kind).put("text", r.text).put("truncated", r.truncated).put("note", r.note).put("chars", r.text.length)
        } catch (e: OutOfMemoryError) { out.put("error", "Berkas terlalu besar untuk diproses.") }
        catch (e: Exception) { out.put("error", "Gagal membaca: " + (e.message ?: e.javaClass.simpleName)) }
    }

    private fun readCapped(s: InputStream, max: Int): Pair<String, Boolean> {
        val buf = ByteArrayOutputStream(); val tmp = ByteArray(8192); var total = 0; var trunc = false
        while (true) {
            val n = s.read(tmp); if (n < 0) break
            val room = max - total
            if (n > room) { buf.write(tmp, 0, room); trunc = true; break }
            buf.write(tmp, 0, n); total += n
        }
        return String(buf.toByteArray(), Charsets.UTF_8) to trunc
    }

    private fun text(s: InputStream, ext: String): R = s.use {
        val (t, tr) = readCapped(it, MAX_TEXT * 2)
        val body = if (ext == "html" || ext == "htm") HtmlText.toText(t) else t
        val cut = body.length > MAX_TEXT
        R(if (cut) body.take(MAX_TEXT) else body, tr || cut, if (ext == "html" || ext == "htm") "HTML diubah menjadi teks polos." else "", "teks")
    }

    private fun pdf(ctx: Context, s: InputStream): R {
        PDFBoxResourceLoader.init(ctx)
        return s.use { st ->
            PDDocument.load(st).use { doc ->
                val pages = doc.numberOfPages
                val stripper = PDFTextStripper().apply { endPage = minOf(pages, 100) }
                var t = stripper.getText(doc).trim()
                var trunc = pages > 100
                if (t.length > MAX_TEXT) { t = t.take(MAX_TEXT); trunc = true }
                val note = when {
                    t.isBlank() -> "Tidak ada teks di PDF (kemungkinan hasil scan; OCR belum tersedia)."
                    pages > 100 -> "PDF $pages halaman; hanya 100 halaman pertama dibaca."
                    else -> "PDF $pages halaman."
                }
                R(t, trunc, note, "pdf")
            }
        }
    }

    private fun zip(s: InputStream): R {
        val listing = StringBuilder(); val body = StringBuilder()
        var n = 0; var textEntries = 0; var budget = 2_000_000; var trunc = false
        ZipInputStream(s).use { z ->
            var e = z.nextEntry
            while (e != null) {
                n++
                if (n <= 100) listing.append("- ").append(e.name).append(if (e.isDirectory) " (folder)\n" else "\n") else trunc = true
                val ext = e.name.substringAfterLast('.', "").lowercase()
                if (!e.isDirectory && ext in TEXT_EXT && textEntries < 20 && budget > 0 && !e.name.contains("..")) {
                    val (t, tr) = readCapped(z, minOf(20_000, budget))
                    budget -= t.length; textEntries++
                    body.append("\n=== ").append(e.name).append(if (tr) " (dipotong)" else "").append(" ===\n").append(t).append('\n')
                }
                e = z.nextEntry
            }
        }
        var all = "ZIP berisi $n berkas:\n$listing$body"
        if (all.length > MAX_TEXT) { all = all.take(MAX_TEXT); trunc = true }
        return R(all, trunc, "Maks 20 berkas teks pertama dibaca isinya.", "zip")
    }

    private fun office(s: InputStream, ext: String): R {
        val sb = StringBuilder(); var found = false
        ZipInputStream(s).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val nm = e.name
                val want = when (ext) {
                    "docx" -> nm == "word/document.xml"
                    "pptx" -> nm.startsWith("ppt/slides/slide") && nm.endsWith(".xml")
                    "xlsx" -> nm == "xl/sharedStrings.xml"
                    else -> nm == "content.xml"
                }
                if (want) { found = true; val (x, _) = readCapped(z, 2_000_000); sb.append(xmlToText(x)).append('\n') }
                e = z.nextEntry
            }
        }
        var t = sb.toString().trim(); var trunc = false
        if (t.length > MAX_TEXT) { t = t.take(MAX_TEXT); trunc = true }
        return R(t, trunc, if (found) (if (ext == "xlsx") "XLSX: hanya teks (shared strings); angka/rumus belum dibaca." else "") else "Struktur dokumen tidak dikenali.", ext)
    }

    private fun xmlToText(x: String): String {
        var s = x.replace(Regex("</(w:p|a:p|si|text:p)>"), "\n").replace(Regex("<(w:tab|w:br)\\s*/>"), " ")
        s = s.replace(Regex("<[^>]+>"), "")
        return HtmlText.unescape(s).lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
    }
}
