package com.aiasisten.control.perception

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject

/** Tahap 4B: membaca notifikasi HANYA dari aplikasi yang diizinkan pengguna. Disimpan di memori saja (maks 50). */
class AssistantNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName == packageName) return
        if (!NotificationAllowlist.isAllowed(this, sbn.packageName)) return
        val n = sbn.notification ?: return
        if (sbn.isOngoing || (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val item = JSONObject().put("ts", sbn.postTime).put("package", sbn.packageName).put("title", title.take(200)).put("text", text.take(500))
        synchronized(buffer) { buffer.addLast(item); while (buffer.size > 50) buffer.removeFirst() }
        onPosted?.invoke(item.toString())
    }

    companion object {
        private val buffer = ArrayDeque<JSONObject>()
        @Volatile var onPosted: ((String) -> Unit)? = null

        fun recent(): JSONArray = synchronized(buffer) { JSONArray(buffer.toList().reversed()) }
        fun clear() = synchronized(buffer) { buffer.clear() }
        fun isEnabled(ctx: Context) = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
}
