package com.aiasisten.control.perception

/** Mengubah HTML menjadi teks polos (tanpa skrip/gaya). */
object HtmlText {
    fun title(html: String): String =
        Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1)?.let { unescape(it).trim() } ?: ""

    fun toText(html: String): String {
        var s = html
        for (tag in listOf("script", "style", "noscript", "svg", "head"))
            s = s.replace(Regex("<$tag[\\s\\S]*?</$tag>", RegexOption.IGNORE_CASE), " ")
        s = s.replace(Regex("<!--[\\s\\S]*?-->"), " ")
        s = s.replace(Regex("<(br|/p|/div|/li|/tr|/h[1-6]|/section|/article|/table)[^>]*>", RegexOption.IGNORE_CASE), "\n")
        s = s.replace(Regex("<[^>]+>"), " ")
        s = unescape(s)
        return s.lines().map { it.replace(Regex("[ \\t\\u00A0]+"), " ").trim() }.filter { it.isNotEmpty() }.joinToString("\n")
    }

    fun unescape(t: String): String {
        var s = t.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
        s = Regex("&#(\\d+);").replace(s) { m -> m.groupValues[1].toIntOrNull()?.let { String(Character.toChars(it)) } ?: "" }
        return s.replace("&amp;", "&")
    }
}
