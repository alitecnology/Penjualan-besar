package com.aiasisten.control

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.aiasisten.control.webview.AndroidBridge

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var bridge: AndroidBridge
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var micCallback: ((Boolean) -> Unit)? = null

    private val micLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        micCallback?.invoke(granted); micCallback = null
    }
    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        filePathCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        filePathCallback = null
    }

    private var pickCallback: ((List<Uri>) -> Unit)? = null
    private val pickLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uris = mutableListOf<Uri>()
        if (res.resultCode == RESULT_OK) {
            val cd = res.data?.clipData
            if (cd != null) { for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
            else res.data?.data?.let { uris.add(it) }
        }
        pickCallback?.invoke(uris); pickCallback = null
    }

    /** Pemilih berkas resmi Android (pengguna memilih sendiri; AI tidak menjelajah penyimpanan). */
    fun pickDocuments(cb: (List<Uri>) -> Unit) {
        pickCallback = cb
        pickLauncher.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        })
    }

    fun hasMicPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Meminta izin mikrofon (sekali, dengan dialog resmi Android) lalu memanggil callback. */
    fun ensureMicPermission(onResult: (Boolean) -> Unit) {
        if (hasMicPermission()) { onResult(true); return }
        micCallback = onResult
        micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply { fitsSystemWindows = true }
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false          // file:///android_asset tetap bisa dimuat
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
        }
        bridge = AndroidBridge(this, webView)
        webView.addJavascriptInterface(bridge, "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            // Hanya halaman lokal aplikasi yang boleh dibuka di WebView.
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = !r.url.toString().startsWith("file:///android_asset/")
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = cb
                return try { fileLauncher.launch(params.createIntent()); true }
                catch (e: Exception) { filePathCallback = null; false }
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        bridge.close()
        webView.removeJavascriptInterface("AndroidBridge")
        webView.destroy()
        super.onDestroy()
    }
}
