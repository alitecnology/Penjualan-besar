package com.aiasisten.control.webview

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Memanggil Gemini dari sisi native agar API Key tidak pernah ada di HTML/JavaScript. */
object GeminiClient {
    const val MODEL = "gemini-3.5-flash-lite"
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    /** Mengembalikan {"ok":true,"text":"..."} atau {"ok":false,"error":"..."}. */
    fun generate(apiKey: String, payload: String, isCancelled: () -> Boolean): JSONObject {
        var conn: HttpURLConnection? = null
        return try {
            val src = JSONObject(payload)
            val body = JSONObject()
            // Hanya kunci yang diizinkan diteruskan; model selalu dipaksa ke MODEL.
            for (k in listOf("systemInstruction", "contents", "generationConfig")) if (src.has(k)) body.put(k, src.get(k))

            conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("x-goog-api-key", apiKey)
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (isCancelled()) return fail("Dibatalkan.")
            if (code !in 200..299) return fail("Gemini HTTP $code: " + errorMessage(text))
            extract(text)
        } catch (e: java.net.UnknownHostException) { fail("Tidak ada koneksi internet.") }
        catch (e: java.net.SocketTimeoutException) { fail("Waktu habis saat menghubungi Gemini.") }
        catch (e: Exception) { fail("Kesalahan: " + (e.message ?: e.javaClass.simpleName)) }
        finally { conn?.disconnect() }
    }

    private fun extract(raw: String): JSONObject {
        val root = JSONObject(raw)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return fail(if (reason.isNotEmpty()) "Permintaan diblokir: $reason" else "Gemini tidak mengembalikan jawaban.")
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false) && p.has("text")) sb.append(p.getString("text"))
        }
        return if (sb.isEmpty()) fail("Jawaban Gemini kosong.") else JSONObject().put("ok", true).put("text", sb.toString())
    }

    private fun errorMessage(raw: String): String =
        try { JSONObject(raw).getJSONObject("error").getString("message").take(300) } catch (e: Exception) { raw.take(200) }

    private fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg)
}
