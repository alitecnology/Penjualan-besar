package com.aiasisten.control.perception

import android.content.Context

/** Daftar aplikasi yang notifikasinya diizinkan pengguna untuk dibaca AI. Default: kosong (tidak ada). */
object NotificationAllowlist {
    private fun prefs(c: Context) = c.getSharedPreferences("perception", Context.MODE_PRIVATE)
    fun get(c: Context): Set<String> = prefs(c).getStringSet("allowed", emptySet()) ?: emptySet()
    fun set(c: Context, pkgs: Set<String>) { prefs(c).edit().putStringSet("allowed", pkgs).apply() }
    fun isAllowed(c: Context, pkg: String) = pkg in get(c)
}
