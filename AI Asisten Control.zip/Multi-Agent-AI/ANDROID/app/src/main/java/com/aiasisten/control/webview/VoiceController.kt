package com.aiasisten.control.webview

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.aiasisten.control.MainActivity
import org.json.JSONObject

/** Perintah suara memakai SpeechRecognizer Android (bahasa Indonesia). Harus dipanggil dari thread UI. */
class VoiceController(private val activity: MainActivity, private val emit: (String, String, String) -> Unit) {
    private var recognizer: SpeechRecognizer? = null

    private fun send(state: String, text: String = "", message: String = "") =
        emit("voice", "", JSONObject().put("state", state).put("text", text).put("message", message).toString())

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(activity)) { send("error", message = "Layanan pengenalan suara tidak tersedia di perangkat ini."); return }
        activity.ensureMicPermission { granted ->
            if (!granted) { send("error", message = "Izin mikrofon belum diberikan."); return@ensureMicPermission }
            stop(silent = true)
            val r = SpeechRecognizer.createSpeechRecognizer(activity)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) = send("listening")
                override fun onPartialResults(b: Bundle?) { first(b)?.let { send("partial", it) } }
                override fun onResults(b: Bundle?) { send("final", first(b) ?: ""); release() }
                override fun onError(code: Int) { send("error", message = describe(code)); release() }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            })
        }
    }

    fun stop(silent: Boolean = false) {
        recognizer?.let { try { it.stopListening() } catch (e: Exception) {} }
        release()
        if (!silent) send("stopped")
    }

    fun release() { recognizer?.let { try { it.destroy() } catch (e: Exception) {} }; recognizer = null }

    private fun first(b: Bundle?) = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

    private fun describe(code: Int) = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Suara tidak terdengar, coba lagi."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Masalah jaringan pada pengenalan suara."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Izin mikrofon belum diberikan."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Pengenal suara sedang sibuk."
        else -> "Pengenalan suara gagal (kode $code)."
    }
}
