# AI 1 — Pekerja (Executor Agent)

## Tahap 4A — Memahami perintah
- Bahasa Indonesia, konteks percakapan, perintah panjang, klarifikasi, dan penilaian risiko: `WEBSITE/js/agents.js`.

## Tahap 4B — Melihat & membaca
- Layar, perubahan tampilan, notifikasi yang diizinkan, website HTTPS, dan dokumen: `WEBSITE/js/perception.js` serta modul `ANDROID/.../perception/` dan `ANDROID/.../accessibility/ScreenReader.kt`.

## Tahap 4C — Melakukan pekerjaan (fondasi awal)
- `WEBSITE/js/agents.js`: `Agents.Executor.execute(actions, { confirmed: true })` menjalankan daftar aksi berurutan (maks. 20 langkah) setelah konfirmasi eksplisit dari pengguna.
- `ANDROID/.../webview/AndroidBridge.kt`: memvalidasi jenis aksi dan meneruskannya ke Android.
- `ANDROID/.../accessibility/AssistantAccessibilityService.kt`: klik elemen yang terlihat, mengisi kolom teks aktif non-sandi, scroll, dan kembali.
- Membuka aplikasi memakai ID paket dan membuka URL HTTP/HTTPS.
- Aksi berhenti pada langkah pertama yang gagal. Emergency Stop membatalkan pekerjaan yang sedang berjalan pada lapisan bridge.

### Batas keamanan
- Tidak membaca atau mengisi kolom sandi melalui executor.
- Tidak membobol akun, melewati autentikasi, atau mengakses data tanpa izin.
- Pengguna harus mengonfirmasi sebelum daftar aksi dijalankan.
- Klik berbasis teks dapat gagal bila label tidak unik/tidak terlihat; verifikasi layar tetap diperlukan.

### Belum tersedia pada 4C
- Pengelola file penuh, upload/download otomatis lintas aplikasi, pengisian formulir kompleks, kontrol mouse/gesture koordinat, dan integrasi API generik.
- Fungsi di atas adalah fondasi eksekusi terbatas, bukan klaim bahwa semua jenis pekerjaan sudah didukung.
- Status runtime: BELUM DIUJI pada perangkat Android; perlu build dan uji manual.
