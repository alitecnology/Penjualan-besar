AI 3 — Ketua Kelas: dibangun pada Tahap 10.
