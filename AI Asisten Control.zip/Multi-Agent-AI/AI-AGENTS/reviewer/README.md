AI 2 — Pengoreksi: dibangun pada Tahap 5.
