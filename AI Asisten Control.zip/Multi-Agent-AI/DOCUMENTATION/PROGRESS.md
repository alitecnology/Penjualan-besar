# Progres Proyek — AI Asisten Control
Nama ZIP wajib: **AI Asisten Control.zip** (jangan diganti). Struktur folder mengikuti roadmap; jangan ganti nama file/folder.

## Status
| Tahap | Status |
|---|---|
| 1 Website | Dasar dibuat (diperlukan agar aplikasi berjalan) |
| 2 Android (WebView, Accessibility) | Kerangka dibuat; Accessibility membaca layar (4B) dan aksi terbatas klik/ketik/scroll (4C, belum diuji) |
| 4A Pekerja: memahami perintah | **DITULIS** — belum diuji di perangkat |
| 4B Pekerja: melihat & membaca | **DITULIS** — belum diuji di perangkat |
| 4C Pekerjaan: fondasi aksi perangkat | **DITULIS — BELUM DIUJI** |
| 4D Laporan pekerjaan | Belum |
| 3, 5–11 | Belum |

## Isi Tahap 4A
Bahasa Indonesia · suara (SpeechRecognizer id-ID) · perintah panjang (dipecah jadi poin) · konteks 12 giliran · klarifikasi maks 3 putaran · Gemini `gemini-3.5-flash-lite` dipanggil dari Kotlin (API Key terenkripsi Keystore, tidak pernah ke JS).

## Cara membangun
1. Ekstrak ZIP, buka folder `ANDROID/` di Android Studio (JDK 17), tunggu Gradle sync (wrapper dibuat otomatis).
2. Run di perangkat/emulator → menu Pengaturan → tempel API Key Gemini → Tes koneksi.
3. Menu Perintah → ketik/ucapkan perintah.

## Daftar uji manual 4A
- [ ] Tes koneksi API Key berhasil
- [ ] Perintah jelas → kartu pemahaman muncul
- [ ] Perintah ambigu ("kirim itu") → muncul pertanyaan + pilihan
- [ ] Perintah >120 kata → dipecah menjadi poin
- [ ] Rujukan konteks ("yang tadi")
- [ ] Mikrofon: izin muncul, teks id-ID terisi
- [ ] Emergency Stop membatalkan proses

## Isi Tahap 4B (menu "Indra")
- Layar: Accessibility Service membaca teks layar aktif (jeda 5 detik); kolom sandi disembunyikan.
- Perubahan tampilan: pemantauan opsional, melaporkan teks muncul/hilang (aplikasi sendiri diabaikan).
- Notifikasi: NotificationListener, HANYA aplikasi dalam daftar izin (default kosong), memori saja (maks 50).
- Teks website: HTTPS saja, alamat lokal/privat diblokir, maks 1,5 MB.
- File: TXT/kode/HTML, PDF (PDFBox-Android), ZIP (daftar + 20 berkas teks), DOCX/XLSX/PPTX/ODF. Maks 25 MB, 10 berkas.
- Semua hasil = DATA tidak tepercaya; baru dikirim ke AI lewat tombol "Kirim ke perintah" / lampiran. AI diperintahkan tidak mengikuti instruksi di dalamnya.
- Emergency Stop: batalkan proses, matikan pemantauan, hapus buffer notifikasi dan hasil bacaan.

## Setelah update dari 4A
Matikan lalu aktifkan ulang Accessibility Service (konfigurasi berubah). Aktifkan juga akses notifikasi (menu Keamanan).

## Daftar uji manual 4B
- [ ] Baca layar aplikasi lain → teks muncul, kolom sandi tersembunyi
- [ ] Pantau perubahan → muncul item "Perubahan …"
- [ ] Notifikasi WhatsApp hanya terbaca setelah diizinkan di daftar
- [ ] Baca website HTTPS; http:// dan alamat 192.168.x ditolak
- [ ] PDF teks, PDF scan (muncul catatan), ZIP, DOCX, HTML, JS terbaca
- [ ] "Kirim ke perintah" → AI memakai isi lampiran
- [ ] Lampiran berisi kalimat perintah palsu → AI menandai sebagai peringatan
- [ ] Emergency Stop membersihkan semuanya

Lanjut: Tahap 4C (melakukan pekerjaan).


## Pembaruan Tahap 4C (fondasi awal)
- Executor JS menjalankan daftar 1–20 aksi secara berurutan hanya setelah `confirmed: true`; berhenti saat aksi gagal.
- Android Bridge membatasi aksi pada klik teks terlihat, ketik pada kolom aktif non-sandi, scroll, kembali, buka aplikasi, dan buka URL HTTP/HTTPS.
- Aksi klik/ketik memerlukan Accessibility Service aktif. Aplikasi harus meminta pengguna mengaktifkannya sendiri melalui pengaturan Android.
- Kolom sandi ditolak untuk pengisian teks. Tidak ada mekanisme untuk melewati autentikasi atau kontrol privasi.
- Belum ada pengelola file penuh, upload/download otomatis, gesture koordinat, atau API generik.
- Belum dilakukan build Gradle maupun pengujian runtime; jangan beri status “Sangat Bagus” sebelum pengujian.

### Daftar uji manual 4C
- [ ] Konfirmasi wajib: `confirmed: false` harus menolak eksekusi.
- [ ] Klik teks/tombol yang terlihat dengan Accessibility aktif.
- [ ] Ketik ke kolom teks biasa yang sedang fokus.
- [ ] Pastikan kolom sandi ditolak.
- [ ] Scroll maju/mundur dan aksi kembali.
- [ ] Buka aplikasi terpasang menggunakan ID paket yang valid.
- [ ] Buka URL HTTP/HTTPS; skema lain harus ditolak.
- [ ] Aksi tidak dikenal dan daftar lebih dari 20 langkah harus ditolak.
- [ ] Langkah gagal menghentikan langkah berikutnya.
- [ ] Emergency Stop saat rangkaian aksi berjalan.

## Build otomatis (GitHub Actions) & perbaikan hasil pengecekan
- Workflow: `.github/workflows/build.yml` (nama workflow: **AI Asisten Control**). Taruh ISI folder `Multi-Agent-AI/` di root repo (folder `.github` harus ada di root), push, buka tab Actions, lalu unduh artifact **AI-Asisten-Control-APK**.
- Proyek tidak punya `gradlew`/wrapper jar, jadi workflow memasang Gradle 8.7 sendiri (sesuai `gradle-wrapper.properties`) dan memakai JDK 17.
- `ANDROID/app/debug.keystore`: kunci debug tetap supaya APK baru bisa menimpa versi lama. Bila sebelumnya terpasang APK dari build lain, uninstall sekali saja.
- Perbaikan kode: `catch (_: Exception)` diganti `catch (e: Exception)` (bentuk `_` kemungkinan besar gagal compile di Kotlin 1.9.24); nama paket layar diambil sebelum `recycle()`; scroll dijalankan pada area yang bisa di-scroll, bukan akar jendela; status Accessibility dibandingkan sebagai ComponentName; `<queries>` launcher ditambahkan agar "buka aplikasi" jalan di Android 11+; alamat web berawalan "http…" (mis. httpbin.org) tidak lagi dikira sudah berskema; teks deskripsi Accessibility dan UI disamakan dengan 4C; versi 0.4.3-C.
- Status runtime tetap: BELUM DIUJI di perangkat. Build Gradle belum dijalankan oleh pembuat berkas ini; hasil build pertama di GitHub adalah ujiannya.
